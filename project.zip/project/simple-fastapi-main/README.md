# simple-fastapi
Simple API made with python and FastAPI which will serve as a basis for infrastructure implementations.
